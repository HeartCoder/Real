
export const destinationsData = {};
export const getDestinationById = () => null;
export const getDestinationsByState = () => [];
